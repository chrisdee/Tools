using namespace System::Reflection;

[assembly:AssemblyProductAttribute(L"DSInternals PowerShell Module")];
[assembly:AssemblyCopyrightAttribute(L"Copyright � 2015-2016 Michael Grafnetter. All rights reserved.")];