﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DSInternals.DataStore.Test
{
    [TestClass]
    public class DistinguishedNameResolverTester
    {
        [TestMethod]
        public void TestMethod1()
        {
            throw new AssertInconclusiveException();
        }
    }
}
