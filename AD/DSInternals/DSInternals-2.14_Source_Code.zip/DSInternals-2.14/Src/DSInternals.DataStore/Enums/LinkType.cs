﻿
namespace DSInternals.DataStore
{
    public enum LinkType
    {
        ForwardLink,
        BackLink
    }
}
