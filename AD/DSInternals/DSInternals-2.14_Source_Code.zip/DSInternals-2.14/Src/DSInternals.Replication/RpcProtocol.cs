﻿
namespace DSInternals.Replication
{
    public enum RpcProtocol
    {
        TCP = 0,
        SMB,
        HTTP
    }
}
