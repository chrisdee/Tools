﻿namespace DSInternals.Common.Exceptions
{
    using System;

    [Serializable]
    public abstract class DirectoryException : Exception
    {
    }
}