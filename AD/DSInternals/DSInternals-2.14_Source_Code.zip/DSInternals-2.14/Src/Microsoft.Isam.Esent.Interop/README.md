DSInternals PowerShell Module
=============================

Microsoft.Database.Isam Library
--------------------------------

This folder contains our fork of the [ESENT Interop library](https://managedesent.codeplex.com), (c) Microsoft.

Previously, we used the official NuGet package, but it contains a few bugs and we do not want to wait a year for them to get fixed.