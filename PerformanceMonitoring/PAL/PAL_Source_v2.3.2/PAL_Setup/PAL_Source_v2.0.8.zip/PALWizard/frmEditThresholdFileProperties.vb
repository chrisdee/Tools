Imports System.Windows.Forms

Public Class frmEditThresholdFileProperties
    Friend sTitle As String
    Friend sVersion As String
    Friend sContentOwners As String
    Friend sFeedbackEmailAddresses As String
    Friend sDescription As String
    Friend ofrmMain As frmPALEditor

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        sTitle = txtThresholdTitle.Text
        sVersion = txtThresholdFileVersion.Text
        sDescription = txtThresholdFileDescription.Text
        sContentOwners = txtThresholdFileContentOwners.Text
        sFeedbackEmailAddresses = txtThresholdFileFeedbackEmailAddresses.Text

        ofrmMain.g_sThresholdFileTitle = sTitle
        ofrmMain.g_sThresholdFileVersion = sVersion
        ofrmMain.g_sThresholdFileDescription = sDescription
        ofrmMain.g_sThresholdFileContentOwners = sContentOwners
        ofrmMain.g_sThresholdFileFeedbackEmailAddresses = sFeedbackEmailAddresses
        ofrmMain.UpdateThresholdFile()
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub frmEditThresholdFileProperties_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtThresholdTitle.Text = sTitle
        txtThresholdFileVersion.Text = sVersion
        txtThresholdFileDescription.Text = sDescription
        txtThresholdFileContentOwners.Text = sContentOwners
        txtThresholdFileFeedbackEmailAddresses.Text = sFeedbackEmailAddresses
    End Sub
End Class
