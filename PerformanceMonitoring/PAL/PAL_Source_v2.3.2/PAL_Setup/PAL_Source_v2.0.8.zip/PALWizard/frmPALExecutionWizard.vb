﻿Imports System.Xml
Imports System.IO
Imports System.Collections.ObjectModel
Imports PALFunctions.PALFunctions

Public Class frmPALExecutionWizard
    Public CounterLogPaths, ThresholdFilePath, AnalysisInterval As String
    Public IsOutputHTML, IsOutputXML, AllCounterStats As Boolean
    'Public HTMLOutputFileName As String = "[LogFileName]_PAL_ANALYSIS_[DateTimeStamp]_[GUID].htm"
    'Public XMLOutputFileName As String = "[LogFileName]_PAL_ANALYSIS_[DateTimeStamp]_[GUID].xml"
    Public PALScriptInstallDirectory, PALBatchFile As String
    Dim dctQuestionCollection As New Dictionary(Of String, PALFunctions.QuestionObject)
    Dim dctThresholdFileInheritanceHistory As New Dictionary(Of String, String)
    Dim dctAnalysisCollection As New Dictionary(Of String, PALFunctions.AnalysisCollectionObject)
    Dim bInitialFormLoad, bLowPriorityExecution As Boolean
    Dim SelectedThresholdFile As String
    Dim sSelectedAnalysisCollectionKey As String
    Dim sSelectedQuestion As String
    Dim BatchFileText As String
    Dim oCommandsQueue As New PALFunctions.PALCommandQueueObject
    Const DEFAULT_OUTPUT_DIRECTORY As String = "[My Documents]\PAL Reports"
    Dim iUB As Integer = -1 'Upper bound of oCommandQueue.aCommandQueues 
    Const PAL_VERSION As String = "v2.0.8"

    Private Function GetCounterLogInformation(ByVal sCounterLogFilePath) As PALFunctions.PALCounterLogFileObject
        Dim sArgs As String
        Dim sCmd As String
        Dim sLine As String
        Dim aLine As String()
        Dim u As Integer
        Dim oCounterLogFile As New PALFunctions.PALCounterLogFileObject
        sCmd = "cmd"
        sArgs = " /C " & Chr(34) & "relog " & sCounterLogFilePath & Chr(34)
        'sCmd = "relog " & sCounterLogFilePath
        'sArgs = " /C " & Chr(34) & "relog " & sCounterLogFilePath & Chr(34)
        Dim consoleApp As New Process
        With consoleApp
            .StartInfo.WindowStyle = ProcessWindowStyle.Hidden
            .StartInfo.CreateNoWindow = True
            .StartInfo.UseShellExecute = False
            .StartInfo.RedirectStandardOutput = True
            .StartInfo.FileName = sCmd
            .StartInfo.Arguments = sArgs
            .Start()
        End With
        Do Until consoleApp.StandardOutput.EndOfStream = True
            sLine = consoleApp.StandardOutput.ReadLine
            If sLine.IndexOf("Begin:") >= 0 Then
                aLine = Split(sLine)
                u = aLine.GetUpperBound(0)
                oCounterLogFile.dBeginTime = aLine(u - 1) & " " & aLine(u)
            End If
            If sLine.IndexOf("End:") >= 0 Then
                aLine = Split(sLine)
                u = aLine.GetUpperBound(0)
                oCounterLogFile.dEndTime = aLine(u - 1) & " " & aLine(u)
            End If
            If sLine.IndexOf("Samples:") >= 0 Then
                aLine = Split(sLine)
                u = aLine.GetUpperBound(0)
                oCounterLogFile.iNumberOfSamples = aLine(u)
            End If
        Loop        
        Return oCounterLogFile
    End Function

    Private Function IsFileFoundInDirectorySearch(ByVal sDirectoryPath As String, ByVal sFileName As String)
        Dim sFilePath, sFile As String
        Dim oFiles As ReadOnlyCollection(Of String)
        Dim aStrings As String()
        'Dim bFound As Boolean
        'bFound = False
        oFiles = My.Computer.FileSystem.GetFiles(sDirectoryPath, FileIO.SearchOption.SearchTopLevelOnly, sFileName)
        For Each sFilePath In oFiles
            aStrings = Split(sFilePath, "\")
            sFile = aStrings(aStrings.GetUpperBound(0))
            If LCase(sFile) = LCase(sFileName) Then
                Return True
            End If
        Next
        Return False
    End Function

    Private Function CheckForPalPs1(ByVal sDirectoryPath As String)
        Dim bFound As Boolean
        bFound = False
        bFound = IsFileFoundInDirectorySearch(sDirectoryPath, "pal.ps1")
        If bFound = False Then
            bFound = IsFileFoundInDirectorySearch("C:\Program Files\PAL", "pal.ps1")
        End If
        If bFound = False Then
            bFound = IsFileFoundInDirectorySearch("C:\Program Files (x86)\PAL", "pal.ps1")
        End If
        Return bFound
    End Function


    Private Sub frmPALExecutionWizard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim bFoundPalPs1 As Boolean
        bFoundPalPs1 = False
        Me.Text = "PAL Wizard " & PAL_VERSION
        'PALScriptInstallDirectory = My.Computer.FileSystem.CurrentDirectory
        PALScriptInstallDirectory = Path.GetDirectoryName(Application.ExecutablePath)
        bFoundPalPs1 = CheckForPalPs1(PALScriptInstallDirectory)
        Do Until bFoundPalPs1 = True
            PALScriptInstallDirectory = InputBox("Please provide the location of the PAL.ps1 script")
            bFoundPalPs1 = CheckForPalPs1(PALScriptInstallDirectory)
        Loop
        'MsgBox(PALScriptInstallDirectory)
        AddNewToCommandQueue(True)
        ThresholdFilePageRefresh()
        OutputPageRefresh()
        BuildQueueCommand()
        TabControl.SelectTab(TabPageWelcome)
        IsOutputHTML = True
        IsOutputXML = False
        AllCounterStats = False
        LinkLabelURL.Links.Remove(LinkLabelURL.Links(0))
        LinkLabelURL.Links.Add(0, LinkLabelURL.Text.Length, "http://pal.codeplex.com")
        LinkLabelLicense.Links.Remove(LinkLabelLicense.Links(0))
        LinkLabelLicense.Links.Add(0, LinkLabelLicense.Text.Length, "http://pal.codeplex.com/license")
        LinkLabelEmailClint.Links.Remove(LinkLabelEmailClint.Links(0))
        LinkLabelEmailClint.Links.Add(0, LinkLabelEmailClint.Text.Length, "mailto:clinth@microsoft.com")
        LinkLabelClinthBlog.Links.Remove(LinkLabelClinthBlog.Links(0))
        LinkLabelClinthBlog.Links.Add(0, LinkLabelClinthBlog.Text.Length, "http://blogs.technet.com/clinth")
        LinkLabelAboutTheAuthorClintH.Links.Remove(LinkLabelAboutTheAuthorClintH.Links(0))
        LinkLabelAboutTheAuthorClintH.Links.Add(0, LinkLabelAboutTheAuthorClintH.Text.Length, "http://blogs.technet.com/clinth/archive/2009/12/03/about-the-author-clint-huffman.aspx")
        LinkLabelSupport.Links.Remove(LinkLabelSupport.Links(0))
        LinkLabelSupport.Links.Add(0, LinkLabelSupport.Text.Length, "http://pal.codeplex.com/workitem/list/basic")
        bLowPriorityExecution = False
    End Sub

    Sub RefreshQueuePage()
        Dim i As Integer
        i = oCommandsQueue.aCommandQueue.GetUpperBound(0)
        oCommandsQueue.aCommandQueue(i).CounterLogPaths = CounterLogPaths
        oCommandsQueue.aCommandQueue(i).ThresholdFilePath = ThresholdFilePath
        oCommandsQueue.aCommandQueue(i).IsOutputHTML = IsOutputHTML
        oCommandsQueue.aCommandQueue(i).IsOutputXML = IsOutputXML
        oCommandsQueue.aCommandQueue(i).AllCounterStats = AllCounterStats
        'oCommandsQueue.aCommandQueue(i).OutputDirectory = OutputDirectory
        oCommandsQueue.aCommandQueue(i).AnalysisInterval = AnalysisInterval
        Dim dctTempQuestionCollection As New Dictionary(Of String, PALFunctions.QuestionObject)
        For Each sKey In dctQuestionCollection.Keys
            Dim oNewQuestion As New PALFunctions.QuestionObject
            oNewQuestion.bAnswer = dctQuestionCollection(sKey).bAnswer
            oNewQuestion.DefaultValue = dctQuestionCollection(sKey).DefaultValue
            oNewQuestion.Question = dctQuestionCollection(sKey).Question
            oNewQuestion.QuestionDataType = dctQuestionCollection(sKey).QuestionDataType
            oNewQuestion.QuestionVarName = dctQuestionCollection(sKey).QuestionVarName
            oNewQuestion.sAnswer = dctQuestionCollection(sKey).sAnswer
            dctTempQuestionCollection.Add(sKey, oNewQuestion)
        Next
        oCommandsQueue.aCommandQueue(i).dctQuestionCollection = dctTempQuestionCollection
        'oCommandsQueue.aCommandQueue(i).RunAtLowPriority = bLowPriorityExecution
        BatchFileText = GenerateTextForCommandQueueTextBox(oCommandsQueue)
        txtBatchText.Text = BatchFileText
    End Sub

    Private Function AddDoubleQuotesOrNot(ByVal sText) As String
        Dim DQ As String
        DQ = Chr(34) ' double quote
        If InStr(sText, Chr(34)) > 0 Then
            Return sText
        Else
            Return DQ & sText & DQ
        End If
    End Function

    Private Sub btnFileBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFileBrowse.Click
        OpenLogFile()
    End Sub

    Sub OpenLogFile()
        Dim sDir As String
        Dim aFileParts() As String
        Dim i As Integer
        OpenFileDialog1.Filter = "Log files (*.blg, *.csv, *.tsv)|*.blg;*.csv;*.tsv|All Files (*.*)|*.*"
        OpenFileDialog1.FileName = ""
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            ComboBoxRunLogFile.Text = Join(OpenFileDialog1.FileNames, ";")
        End If
        'My.Computer.FileSystem.CurrentDirectory = sWorkingDirectory
        aFileParts = Split(OpenFileDialog1.FileNames(0), "\")
        sDir = "."
        For i = 0 To UBound(aFileParts)
            If i = 0 Then
                sDir = aFileParts(i)
            Else
                If i < UBound(aFileParts) Then
                    sDir = sDir & "\" & aFileParts(i)
                End If
            End If
        Next
        ReadBlgFilesIntoMemory(sDir)
    End Sub

    Sub ReadBlgFilesIntoMemory(ByVal sDir)
        Dim sFile As String
        Dim oFiles As ReadOnlyCollection(Of String)
        If sDir = "" Then
            sDir = "."
        End If
        ComboBoxRunLogFile.Items.Clear()
        oFiles = My.Computer.FileSystem.GetFiles(sDir, FileIO.SearchOption.SearchTopLevelOnly, "*.blg")
        For Each sFile In oFiles
            ComboBoxRunLogFile.Items.Add(sFile)
        Next
    End Sub

    Sub ReadAnalysisCollectionFilesIntoMemory()
        Dim sFile As String
        Dim sFileContents As String
        Dim oXmlRoot As XmlNode
        Dim oFiles As ReadOnlyCollection(Of String)
        Dim sKey, sText As String

        dctQuestionCollection.Clear()
        oFiles = My.Computer.FileSystem.GetFiles(".", FileIO.SearchOption.SearchTopLevelOnly, "*.xml")
        For Each sFile In oFiles
            sFileContents = My.Computer.FileSystem.ReadAllText(sFile)
            Dim oXmlDoc As New XmlDocument
            oXmlDoc.Load(sFile)
            oXmlRoot = oXmlDoc.DocumentElement
            Dim oAnalysisCollection As New PALFunctions.AnalysisCollectionObject
            Try
                If oXmlRoot.Attributes("NAME").Value <> "" Then
                    oAnalysisCollection.Name = oXmlRoot.Attributes("NAME").Value
                    oAnalysisCollection.Version = oXmlRoot.Attributes("VERSION").Value
                    oAnalysisCollection.Description = oXmlRoot.Attributes("DESCRIPTION").Value
                    oAnalysisCollection.ContentOwners = oXmlRoot.Attributes("CONTENTOWNERS").Value
                    oAnalysisCollection.FeedbackEmailAddresses = oXmlRoot.Attributes("FEEDBACKEMAILADDRESS").Value
                    oAnalysisCollection.FilePath = sFile
                    oAnalysisCollection.XmlRoot = oXmlRoot
                    sKey = oAnalysisCollection.Name
                    '// Check for duplicates
                    If dctAnalysisCollection.ContainsKey(sKey) = False Then
                        dctAnalysisCollection.Add(sKey, oAnalysisCollection)
                    Else
                        sText = "Two or more threshold files contain the same title. Only one of them will be listed." & vbNewLine & _
                        "The following threshold files are in conflict: " & vbNewLine & _
                        vbNewLine & _
                        "Threshold File Title: " & dctAnalysisCollection(sKey).Name & vbNewLine & _
                        "Threshold File Version: " & dctAnalysisCollection(sKey).Version & vbNewLine & _
                        "Threshold Fiel Path: " & dctAnalysisCollection(sKey).FilePath & vbNewLine & _
                        vbNewLine & _
                        "Threshold File Title: " & oAnalysisCollection.Name & vbNewLine & _
                        "Threshold File Version: " & oAnalysisCollection.Version & vbNewLine & _
                        "Threshold Fiel Path: " & oAnalysisCollection.FilePath
                        MsgBox(sText, MsgBoxStyle.Information, "Threshold File Conflict")
                    End If
                End If
            Catch ex As Exception

            End Try
        Next
    End Sub

    Sub ThresholdFilePageFocus()
        'If ComboBoxAnalysisCollection.SelectedItem = "" Then
        '    ComboBoxAnalysisCollection.SelectedItem = "System Overview"
        '    sSelectedAnalysisCollectionKey = ComboBoxAnalysisCollection.SelectedItem
        '    RefreshAnalysisCollectionSection(True)
        'End If
        'RefreshAnalysisCollectionSection(True)
    End Sub

    Sub ThresholdFilePageRefresh()
        ReadAnalysisCollectionFilesIntoMemory()
        ComboBoxAnalysisCollection.Items.Clear()
        For Each sKey In dctAnalysisCollection.Keys
            ComboBoxAnalysisCollection.Items.Add(sKey)
        Next
        For Each oItem In ComboBoxAnalysisCollection.Items
            If oItem = "System Overview" Then
                ComboBoxAnalysisCollection.SelectedItem = "System Overview"
            End If
        Next
        'ThresholdFilePath
    End Sub

    Sub RefreshCounterLogPage()
        ReadBlgFilesIntoMemory(".")
    End Sub

    Private Sub TabControl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl.SelectedIndexChanged
        Select Case TabControl.SelectedTab.Text
            Case "Counter Log"
                RefreshCounterLogPage()
            Case "Threshold File"
                ThresholdFilePageFocus()
            Case "Output Options"
                RefreshOutputOptionsPage()
            Case "Queue"
                RefreshQueuePage()
        End Select

    End Sub

    Private Sub btnAnalysisCollectionRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAnalysisCollectionRefresh.Click
        ThresholdFilePageRefresh()
    End Sub

    Private Sub ComboBoxAnalysisCollection_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxAnalysisCollection.SelectedIndexChanged
        sSelectedAnalysisCollectionKey = ComboBoxAnalysisCollection.SelectedItem
        RefreshAnalysisCollectionSection(False)
    End Sub

    Sub ProcessThresholdFileInheritance(ByVal sFilePath As String)
        '// Inherit questions from other threshold files if specified in the threshold file.
        Dim oXmlDoc As New XmlDocument
        Dim oXmlRoot As XmlNode
        Dim sPalThresholdFilePath As String
        If System.IO.File.Exists(sFilePath) = True Then
            oXmlDoc.Load(sFilePath)
            oXmlRoot = oXmlDoc.DocumentElement
            If dctThresholdFileInheritanceHistory.ContainsKey(sFilePath) = False Then
                dctThresholdFileInheritanceHistory.Add(sFilePath, "")
            End If
            For Each oXmlNode In oXmlRoot.SelectNodes("//INHERITANCE")
                sPalThresholdFilePath = PALScriptInstallDirectory & "\" & oXmlNode.Attributes("FILEPATH").Value
                If dctThresholdFileInheritanceHistory.ContainsKey(sPalThresholdFilePath) = False Then
                    dctThresholdFileInheritanceHistory.Add(sPalThresholdFilePath, "")
                    ProcessThresholdFileInheritance(sPalThresholdFilePath)
                End If
            Next
        End If
    End Sub

    Sub RefreshAnalysisCollectionSection(ByVal bForce As Boolean)
        Dim oXmlNode As XmlNode
        Dim oXmlDoc As New XmlDocument
        Dim oXmlRoot As XmlNode
        Dim sKey, sPalThresholdFilePath As String
        Dim bFound As Boolean

        txtQuestion.Text = ""
        txtQuestion.Enabled = False
        txtQuestionAnswer.Text = ""
        txtQuestionAnswer.Enabled = False
        ComboBoxQuestionAnswer.Text = ""
        ComboBoxQuestionAnswer.Enabled = False

        If String.IsNullOrEmpty(sSelectedAnalysisCollectionKey) = True Then
            MsgBox("No threshold file found or no threshold files are located in the local directory. Try placing or creating new PAL v1.1 threshold files in the local directory and try again.")
            Exit Sub
        End If

        '// Check to see if the Analysis Collection selection has really changed or not unless forced to refresh.
        If bForce = False Then
            If ThresholdFilePath = dctAnalysisCollection(sSelectedAnalysisCollectionKey).FilePath Then
                Exit Sub
            End If
        End If
        ThresholdFilePath = dctAnalysisCollection(sSelectedAnalysisCollectionKey).FilePath
        txtThresholdFileName.Text = ExtractFileNameFromFilePath(ThresholdFilePath)
        txtAnalysisCollectionDescription.Text = dctAnalysisCollection(sSelectedAnalysisCollectionKey).Description
        txtThresholdFileContentOwners.Text = dctAnalysisCollection(sSelectedAnalysisCollectionKey).ContentOwners & " (" & dctAnalysisCollection(sSelectedAnalysisCollectionKey).FeedbackEmailAddresses & ")"

        dctThresholdFileInheritanceHistory.Clear()
        ProcessThresholdFileInheritance(ThresholdFilePath)

        ListBoxQuestions.Items.Clear()
        dctQuestionCollection.Clear()
        For Each sPalThresholdFilePath In dctThresholdFileInheritanceHistory.Keys
            If System.IO.File.Exists(sPalThresholdFilePath) = True Then
                oXmlDoc.Load(sPalThresholdFilePath)
                oXmlRoot = oXmlDoc.DocumentElement
                For Each oXmlNode In oXmlRoot.SelectNodes("//QUESTION")
                    bFound = False
                    For Each sKey In ListBoxQuestions.Items
                        If oXmlNode.Attributes("QUESTIONVARNAME").Value = sKey Then
                            bFound = True
                            Exit For
                        End If
                    Next
                    If bFound = False Then
                        ListBoxQuestions.Items.Add(oXmlNode.Attributes("QUESTIONVARNAME").Value)
                        Dim oQuestion As New PALFunctions.QuestionObject
                        oQuestion.QuestionVarName = oXmlNode.Attributes("QUESTIONVARNAME").Value
                        oQuestion.QuestionDataType = oXmlNode.Attributes("DATATYPE").Value
                        oQuestion.DefaultValue = oXmlNode.Attributes("DEFAULTVALUE").Value
                        oQuestion.Question = oXmlNode.InnerText
                        If oQuestion.QuestionDataType = "boolean" Then
                            If oQuestion.DefaultValue = "True" Then
                                oQuestion.bAnswer = True
                            Else
                                oQuestion.bAnswer = False
                            End If
                        Else
                            oQuestion.sAnswer = oQuestion.DefaultValue
                        End If
                        dctQuestionCollection.Add(oQuestion.QuestionVarName, oQuestion)
                        If ListBoxQuestions.SelectedItem = Nothing Then
                            ListBoxQuestions.SelectedItem = oXmlNode.Attributes("QUESTIONVARNAME").Value
                        End If
                    End If
                Next

            End If
        Next
    End Sub

    Function ExtractFileNameFromFilePath(ByVal sFilePath) As String
        Dim aString() As String
        Dim sFileName As String
        aString = Split(sFilePath, "\")
        sFileName = aString(aString.GetUpperBound(0))
        Return sFileName
    End Function

    Private Sub btnOutputDirectoryBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOutputDirectoryBrowse.Click
        BrowseForOutputDirectory()
    End Sub

    Sub BrowseForOutputDirectory()
        If FolderBrowserDialog1.ShowDialog = DialogResult.OK And iUB >= 0 Then
            oCommandsQueue.aCommandQueue(iUB).OutputDirectory = FolderBrowserDialog1.SelectedPath
            txtOutputDirectoryPath.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory
        End If
    End Sub

    Sub RefreshOutputOptionsPage()
        If iUB >= 0 Then
            txtOutputDirectoryPath.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory
        End If
    End Sub

    Private Sub txtOutputDirectoryPath_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtOutputDirectoryPath.TextChanged
        'OutputDirectory = txtOutputDirectoryPath.Text
        If iUB >= 0 Then
            oCommandsQueue.aCommandQueue(iUB).OutputDirectory = txtOutputDirectoryPath.Text
            txtFullHTMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory & "\" & oCommandsQueue.aCommandQueue(iUB).HTMLOutputFileName
            txtFullXMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory & "\" & oCommandsQueue.aCommandQueue(iUB).XMLOutputFileName
        End If
    End Sub

    Sub ExecuteBatchFile(ByVal sBatchFilePath As String)
        Dim sArgs As String
        Dim sCmd As String

        'Dim sBatchFilePath As String
        'Dim aLinesOfExecution(), sLineOfExecution, sSplitText As String
        'Const LOW_PRIORITY = "start /LOW /WAIT "
        'sBatchFilePath = ""
        'sSplitText = "CScript"
        'aLinesOfExecution = Split(sBatchText, "CScript", -1, CompareMethod.Text)
        'If bLowPriorityExecution = True Then
        '    For i = 0 To aLinesOfExecution.GetUpperBound(0)
        '        aLinesOfExecution(i) = LOW_PRIORITY & aLinesOfExecution(i)
        '    Next
        'End If


        'For i = 1 To aPALCommandQueue.GetUpperBound(0)
        '    aPALCommandQueue(i).BuildCommandLine()
        '    PALBatchFile = GenerateNewGUID() & TEMP_BATCH_FILE
        'sBatchFilePath = SaveTextAsBatchFile(PALBatchFile, sLineOfExecution)
        sCmd = "cmd"
        sArgs = " /K " & Chr(34) & sBatchFilePath & Chr(34)
        Dim consoleApp As New Process
        With consoleApp
            .StartInfo.UseShellExecute = True
            .StartInfo.RedirectStandardOutput = False
            .StartInfo.FileName = sCmd
            .StartInfo.Arguments = sArgs
            .Start()
        End With
        'Next

    End Sub

    Private Sub txtBatchText_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtBatchText.TextChanged
        BatchFileText = txtBatchText.Text
    End Sub

    Public Function GenerateNewGUID()
        Return "{" & Guid.NewGuid().ToString & "}"
    End Function

    Function IsCounterLogDataValid()
        If ComboBoxRunLogFile.Text = "" Then
            MsgBox("Please specify a valid counter log path.")
            Return False
            'TabControl.SelectTab(TabPage2)
        Else
            Return True
        End If
    End Function

    Private Sub ComboBoxRunLogFile_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBoxRunLogFile.TextChanged
        Dim i As Integer
        CounterLogPaths = ComboBoxRunLogFile.Text
        i = oCommandsQueue.aCommandQueue.GetUpperBound(0)
        oCommandsQueue.aCommandQueue(i).CounterLogPaths = CounterLogPaths

        If CheckBoxRestrictToADateTimeRange.Checked = True Then
            UpdateCheckBoxRestrictToDateTimeRange()
        End If
    End Sub

    Private Sub ComboBoxInterval_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBoxInterval.TextChanged
        AnalysisInterval = ComboBoxInterval.Text
    End Sub

    Private Sub CheckBoxXMLOutput_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBoxXMLOutput.CheckedChanged
        If CheckBoxXMLOutput.Checked = True Then
            IsOutputXML = "True"
            lblXMLFileNameLabel.Enabled = True
            txtXMLOutputFileName.Enabled = True
            lblFullXMLOutputPathLabel.Enabled = True
            txtFullXMLOutputFileName.Enabled = True
        Else
            IsOutputXML = "False"
            lblXMLFileNameLabel.Enabled = False
            txtXMLOutputFileName.Enabled = False
            lblFullXMLOutputPathLabel.Enabled = False
            txtFullXMLOutputFileName.Enabled = False
        End If
        IsBothOutputOptionsUnchecked()
    End Sub

    Private Sub CheckBoxHTMLOutput_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBoxHTMLOutput.CheckedChanged
        If CheckBoxHTMLOutput.Checked = True Then
            IsOutputHTML = "True"
            lblHTMLReportFileName.Enabled = True
            txtHTMLOutputFileName.Enabled = True
            lblFullHTMLOutputDirectoryLabel.Enabled = True
            txtFullHTMLOutputFileName.Enabled = True
        Else
            IsOutputHTML = "False"
            lblHTMLReportFileName.Enabled = False
            txtHTMLOutputFileName.Enabled = False
            lblFullHTMLOutputDirectoryLabel.Enabled = False
            txtFullHTMLOutputFileName.Enabled = False
        End If
        IsBothOutputOptionsUnchecked()
    End Sub

    Sub IsBothOutputOptionsUnchecked()
        If CheckBoxHTMLOutput.Checked = False And CheckBoxXMLOutput.Checked = False Then
            MsgBox("At least one output type must be checked.")
            CheckBoxHTMLOutput.Checked = True
        End If
    End Sub

    Private Sub btnEditThresholdFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEditThresholdFile.Click
        Dim ofrmPALEditor As New frmPALEditor
        If ComboBoxAnalysisCollection.Text <> "" Then
            ofrmPALEditor.sThresholdFilePath = ThresholdFilePath
        End If
        ofrmPALEditor.Text = "PAL Editor - " & ComboBoxAnalysisCollection.Text
        ofrmPALEditor.ofrmPALExecutionWizard = Me
        ofrmPALEditor.Show()
    End Sub

    Private Sub btnExportThresholdFileToPerfmonTemplate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportThresholdFileToPerfmonTemplate.Click
        ExportToThresholdFileToPerfmonTemplate()
    End Sub

    'Sub DeletePALBatchFile()
    '    '// Delete the batch file to reduce clutter in the %temp% directory.
    '    My.Computer.FileSystem.DeleteFile(PALBatchFile)
    'End Sub

    Private Sub LinkLabelURL_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabelURL.LinkClicked
        Dim sInfo As New ProcessStartInfo(e.Link.LinkData.ToString())
        Process.Start(sInfo)
    End Sub

    Private Sub LinkLabelLicense_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabelLicense.LinkClicked
        Dim sInfo As New ProcessStartInfo(e.Link.LinkData.ToString())
        Process.Start(sInfo)
    End Sub

    Private Sub CheckBoxAddMoreToThisQueue_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'If CheckBoxAddMoreToThisQueue.Checked = True Then
        '    btnNextOnPage4.Text = ""
        'End If
    End Sub

    Private Sub CheckBoxRunAsLowPriority_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxRunAsLowPriority.CheckedChanged
        If CheckBoxRunAsLowPriority.Checked = True Then
            bLowPriorityExecution = True
        Else
            bLowPriorityExecution = False
        End If
        oCommandsQueue.bLowPriorityExecution = bLowPriorityExecution
    End Sub

    Private Sub btnNextOnPageExecute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageExecute.Click
        If RadExecuteAndRunWizardAgain.Checked = True Then
            oCommandsQueue.SaveTextAsBatchFile(oCommandsQueue.sBatchFilePath, oCommandsQueue.BuildBatchFileText(oCommandsQueue), PALScriptInstallDirectory)
            ExecuteBatchFile(oCommandsQueue.sBatchFilePath)
            AddNewToCommandQueue(True)
            TabControl.SelectTab(TabPageCounterLog)
        Else
            If RadAddMoreToQueue.Checked = True Then
                AddNewToCommandQueue(False)
                TabControl.SelectTab(TabPageCounterLog)
            Else
                oCommandsQueue.SaveTextAsBatchFile(oCommandsQueue.sBatchFilePath, oCommandsQueue.BuildBatchFileText(oCommandsQueue), PALScriptInstallDirectory)
                ExecuteBatchFile(oCommandsQueue.sBatchFilePath)
                Me.Close()
            End If
        End If
    End Sub

    Sub AddNewToCommandQueue(ByVal bClear As Boolean)
        Dim a, b, c As Integer
        Dim aPALCommands() As PALFunctions.PALCommandObject
        Dim oPALCommand As New PALFunctions.PALCommandObject
        Dim sPreviousOutputDirectory, sPreviousThresholdFilePath, sPreviousAnalysisInterval As String

        If iUB >= 0 Then
            sPreviousOutputDirectory = oCommandsQueue.aCommandQueue(iUB).OutputDirectory
            sPreviousThresholdFilePath = oCommandsQueue.aCommandQueue(iUB).ThresholdFilePath
            sPreviousAnalysisInterval = oCommandsQueue.aCommandQueue(iUB).AnalysisInterval
        Else
            sPreviousOutputDirectory = ""
            sPreviousThresholdFilePath = ""
            sPreviousAnalysisInterval = ""
        End If

        If bClear = True Then
            ReDim aPALCommands(0)
            aPALCommands(0) = oPALCommand
            oCommandsQueue.aCommandQueue = aPALCommands
            iUB = 0
        Else
            a = oCommandsQueue.aCommandQueue.GetUpperBound(0)
            ReDim aPALCommands(a + 1)
            For b = 0 To a
                aPALCommands(b) = oCommandsQueue.aCommandQueue(b)
            Next
            c = aPALCommands.GetUpperBound(0)
            aPALCommands(c) = oPALCommand
            oCommandsQueue.aCommandQueue = aPALCommands
            iUB = c
        End If
        '// Set the new command queue item properties to previous settings.
        If sPreviousOutputDirectory <> "" Then
            oCommandsQueue.aCommandQueue(iUB).OutputDirectory = sPreviousOutputDirectory
        End If
        If sPreviousThresholdFilePath <> "" Then
            oCommandsQueue.aCommandQueue(iUB).ThresholdFilePath = sPreviousThresholdFilePath
        End If
        If sPreviousAnalysisInterval <> "" Then
            oCommandsQueue.aCommandQueue(iUB).AnalysisInterval = sPreviousAnalysisInterval
        End If
        oCommandsQueue.aCommandQueue(iUB).PALScriptInstallDirectory = PALScriptInstallDirectory
    End Sub

    Sub RemoveLastFromCommandQueue()
        Dim a As Integer
        Dim aPALCommands() As PALFunctions.PALCommandObject
        Dim oPALCommand As New PALFunctions.PALCommandObject

        If iUB < 1 Then
            MsgBox("The last item in the queue cannot be removed, but can be edited by the rest of the wizard.")
            Exit Sub
        End If

        ReDim aPALCommands(iUB - 1)
        For a = 0 To iUB - 1
            aPALCommands(a) = oCommandsQueue.aCommandQueue(a)
        Next
        oCommandsQueue.aCommandQueue = aPALCommands
        iUB = oCommandsQueue.aCommandQueue.GetUpperBound(0)
    End Sub

    Sub BuildQueueCommand()
        BatchFileText = GenerateTextForCommandQueueTextBox(oCommandsQueue)

        'Dim sKey As String
        'Dim sBatchLine, sLogFile, sThresholdFile, sInterval, sOutputDirectory, sIsOutputHTML, sIsOutputXML As String

        'sLogFile = "/LOG:" & AddDoubleQuotesOrNot(CounterLogPaths)
        'sThresholdFile = "/THRESHOLDFILE:" & AddDoubleQuotesOrNot(ThresholdFilePath)
        'sInterval = "/INTERVAL:" & AddDoubleQuotesOrNot(ConvertIntervalToSeconds(AnalysisInterval))
        'sIsOutputHTML = "/ISOUTPUTHTML:" & IsOutputHTML
        'sIsOutputXML = "/ISOUTPUTXML:" & IsOutputXML
        'If OutputDirectory = DEFAULT_OUTPUT_DIRECTORY Then
        '    '// If set to the default of PAL Reports, then omit the output directory setting.
        '    sOutputDirectory = ""
        'Else
        '    sOutputDirectory = "/OUTPUTDIR:" & Chr(34) & OutputDirectory & Chr(34)
        'End If
        'If sOutputDirectory = "" Then
        '    sBatchLine = "CScript " & AddDoubleQuotesOrNot(WorkingDirectory & "\PAL.vbs") & vbNewLine & sLogFile & vbNewLine & sThresholdFile & vbNewLine & sInterval & vbNewLine & sIsOutputHTML & vbNewLine & sIsOutputXML
        'Else
        '    sBatchLine = "CScript " & AddDoubleQuotesOrNot(WorkingDirectory & "\PAL.vbs") & vbNewLine & sLogFile & vbNewLine & sThresholdFile & vbNewLine & sInterval & vbNewLine & sIsOutputHTML & vbNewLine & sIsOutputXML & vbNewLine & sOutputDirectory
        'End If
        'If dctQuestionCollection.Count > 0 Then
        '    'Dim dctAnswers As New Dictionary(Of String, String)
        '    For Each sKey In dctQuestionCollection.Keys
        '        If dctQuestionCollection(sKey).QuestionDataType = "boolean" Then
        '            If dctQuestionCollection(sKey).bAnswer = True Then
        '                sBatchLine = sBatchLine & vbNewLine & "/" & sKey & ":True"
        '            Else
        '                sBatchLine = sBatchLine & vbNewLine & "/" & sKey & ":False"
        '            End If
        '        Else
        '            sBatchLine = sBatchLine & vbNewLine & "/" & sKey & ":" & dctQuestionCollection(sKey).sAnswer
        '        End If
        '    Next
        'End If
        ''If CheckBoxRunAsLowPriority.Checked = True Then
        ''    txtBatchText.Text = txtBatchText.Text & LOW_PRIORITY & vbNewLine & sBatchLine & vbNewLine
        ''Else
        ''    txtBatchText.Text = txtBatchText.Text & sBatchLine & vbNewLine
        ''End If
        'BatchFileText = sBatchLine
    End Sub

    Private Sub RadAddMoreToQueue_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadAddMoreToQueue.CheckedChanged
        If RadAddMoreToQueue.Checked = True Then
            btnNextOnPageExecute.Text = "Add"
        Else
            btnNextOnPageExecute.Text = "Finish"
        End If
    End Sub

    Function GenerateTextForCommandQueueTextBox(ByVal oCommandQueue As PALFunctions.PALCommandQueueObject)
        Dim sText As String
        'Const sCommandDelimitor As String = "========COMMAND_DELIMITOR========"
        Dim oCommand As PALFunctions.PALCommandObject
        sText = ""
        For Each oCommand In oCommandQueue.aCommandQueue
            sText = sText & oCommand.BuildQueryStyleCommandLine() & vbNewLine & vbNewLine
        Next
        Return sText
    End Function

    Sub OutputPageRefresh()
        If iUB >= 0 Then
            txtHTMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).HTMLOutputFileName
            txtXMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).XMLOutputFileName
            txtFullHTMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory & "\" & oCommandsQueue.aCommandQueue(iUB).HTMLOutputFileName
            txtFullXMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory & "\" & oCommandsQueue.aCommandQueue(iUB).XMLOutputFileName
        End If
    End Sub

    Private Sub txtHTMLReportFileName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtHTMLOutputFileName.TextChanged
        If iUB >= 0 Then
            oCommandsQueue.aCommandQueue(iUB).HTMLOutputFileName = txtHTMLOutputFileName.Text
            txtFullHTMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory & "\" & oCommandsQueue.aCommandQueue(iUB).HTMLOutputFileName
        End If
    End Sub

    Private Sub txtXMLOutputFileName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtXMLOutputFileName.TextChanged
        If iUB >= 0 Then
            oCommandsQueue.aCommandQueue(iUB).XMLOutputFileName = txtXMLOutputFileName.Text
            txtFullXMLOutputFileName.Text = oCommandsQueue.aCommandQueue(iUB).OutputDirectory & "\" & oCommandsQueue.aCommandQueue(iUB).XMLOutputFileName
        End If
    End Sub

    Private Sub btnRemoveLastFromQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveLastFromQueue.Click
        RemoveLastFromCommandQueue()
        RefreshQueuePage()
    End Sub

    Private Sub UpdateCheckBoxRestrictToDateTimeRange()
        Dim oCounterLogFile As PALFunctions.PALCounterLogFileObject
        lblDateTimeRangeNote.Text = "Status: Please wait. Retrieving time range from counter log using Relog.exe from command line..."
        lblDateTimeRangeNote.Update()
        oCounterLogFile = GetCounterLogInformation(ComboBoxRunLogFile.Text)
        If oCounterLogFile.dBeginTime <> "#12:00:00 AM#" Then
            DateTimePickerBeginTime.Value = oCounterLogFile.dBeginTime
            DateTimePickerEndTime.Value = oCounterLogFile.dEndTime
            lblDateTimeRangeNote.Text = "Status: Done"
            lblDateTimeRangeNote.Update()
        Else
            lblDateTimeRangeNote.Text = "Status: An error occurred retrieving time range from counter log using Relog.exe from command line."
            lblDateTimeRangeNote.Update()
        End If
    End Sub

    Private Sub CheckBoxRestrictToADateTimeRange_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxRestrictToADateTimeRange.CheckedChanged
        If CheckBoxRestrictToADateTimeRange.Checked = True Then
            lblBeginTime.Enabled = True
            lblEndTime.Enabled = True
            DateTimePickerBeginTime.Enabled = True
            DateTimePickerEndTime.Enabled = True
            lblDateTimeRangeNote.Enabled = True
            UpdateCheckBoxRestrictToDateTimeRange()
        Else
            lblBeginTime.Enabled = False
            lblEndTime.Enabled = False
            DateTimePickerBeginTime.Enabled = False
            DateTimePickerEndTime.Enabled = False
            lblDateTimeRangeNote.Enabled = False
        End If
        IsCheckBoxRestrictToADateTimeRangeCheckedUnchecked()
    End Sub

    Sub IsCheckBoxRestrictToADateTimeRangeCheckedUnchecked()
        If CheckBoxRestrictToADateTimeRange.Checked = True Then '
            oCommandsQueue.aCommandQueue(iUB).TimeRangeRestriction = True
        Else
            oCommandsQueue.aCommandQueue(iUB).TimeRangeRestriction = False
        End If
    End Sub

    Private Sub DateTimePickerBeginTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerBeginTime.ValueChanged
        oCommandsQueue.aCommandQueue(iUB).BeginTime = DateTimePickerBeginTime.Value
    End Sub

    Private Sub DateTimePickerEndTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerEndTime.ValueChanged
        oCommandsQueue.aCommandQueue(iUB).EndTime = DateTimePickerEndTime.Value
    End Sub

    Private Sub btnNextOnPageWelcome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageWelcome.Click
        TabControl.SelectTab(TabPageCounterLog)
    End Sub

    Private Sub btnPreviousOnPageCounterLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageCounterLog.Click
        TabControl.SelectTab(TabPageWelcome)
    End Sub

    Private Sub btnNextOnPageCounterLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageCounterLog.Click
        TabControl.SelectTab(TabPageThresholdFile)
    End Sub

    Private Sub btnPreviousOnPageThresholdFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageThresholdFile.Click
        TabControl.SelectTab(TabPageCounterLog)
    End Sub

    Private Sub btnNextOnPageThresholdFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageThresholdFile.Click
        TabControl.SelectTab(TabPageQuestions)
    End Sub

    Private Sub btnPreviousOnPageQuestions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageQuestions.Click
        TabControl.SelectTab(TabPageThresholdFile)
    End Sub

    Private Sub btnNextOnPageQuestions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageQuestions.Click
        TabControl.SelectTab(TabPageAnalysisInterval)
    End Sub

    Private Sub btnPreviousOnPageAnalysisInterval_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageAnalysisInterval.Click
        TabControl.SelectTab(TabPageQuestions)
    End Sub

    Private Sub btnNextOnPageAnalysisInterval_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageAnalysisInterval.Click
        TabControl.SelectTab(TabPageOutputOptions)
    End Sub

    Private Sub btnPreviousOnPageOutputOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageOutputOptions.Click
        TabControl.SelectTab(TabPageAnalysisInterval)
    End Sub

    Private Sub btnNextOnPageOutputOptions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageOutputOptions.Click
        TabControl.SelectTab(TabPageQueue)
    End Sub

    Private Sub btnPreviousOnPageQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageQueue.Click
        TabControl.SelectTab(TabPageOutputOptions)
    End Sub

    Private Sub btnNextOnPageQueue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextOnPageQueue.Click
        TabControl.SelectTab(TabPageExecute)
    End Sub

    Private Sub btnPreviousOnPageExecute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreviousOnPageExecute.Click
        TabControl.SelectTab(TabPageQueue)
    End Sub

    Private Sub ListBoxQuestions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBoxQuestions.SelectedIndexChanged
        sSelectedQuestion = ListBoxQuestions.SelectedItem
        If String.IsNullOrEmpty(sSelectedQuestion) = True Then
            Exit Sub
        End If
        txtQuestion.Enabled = True
        txtQuestionAnswer.Enabled = True
        ComboBoxQuestionAnswer.Enabled = True
        If dctQuestionCollection.Count = 0 Then
            Exit Sub
        End If
        txtQuestion.Text = dctQuestionCollection(sSelectedQuestion).Question
        If dctQuestionCollection(sSelectedQuestion).QuestionDataType = "boolean" Then
            txtQuestionAnswer.Enabled = False
            txtQuestionAnswer.Visible = False
            'txtQuestionAnswer.Text = ""
            lblQuestionAnswerValueString.Visible = False
            lblQuestionAnswerValueBoolean.Visible = True
            ComboBoxQuestionAnswer.Enabled = True
            ComboBoxQuestionAnswer.Visible = True
            If dctQuestionCollection(sSelectedQuestion).bAnswer = True Then
                ComboBoxQuestionAnswer.Text = "True"
            Else
                ComboBoxQuestionAnswer.Text = "False"
            End If
        Else
            lblQuestionAnswerValueString.Visible = True
            lblQuestionAnswerValueBoolean.Visible = False
            txtQuestionAnswer.Enabled = True
            txtQuestionAnswer.Visible = True
            ComboBoxQuestionAnswer.Enabled = False
            ComboBoxQuestionAnswer.Visible = False
            'ComboBoxQuestionAnswer.Text = ""
            txtQuestionAnswer.Text = dctQuestionCollection(sSelectedQuestion).sAnswer
        End If
    End Sub

    Private Sub ComboBoxQuestionAnswer_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxQuestionAnswer.SelectedIndexChanged
        If ComboBoxQuestionAnswer.Text = "True" Then
            dctQuestionCollection(sSelectedQuestion).bAnswer = True
        Else
            dctQuestionCollection(sSelectedQuestion).bAnswer = False
        End If
        RefreshQueuePage()
    End Sub

    Private Sub txtQuestionAnswer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtQuestionAnswer.TextChanged
        If txtQuestionAnswer.Text <> "" Then
            dctQuestionCollection(sSelectedQuestion).sAnswer = txtQuestionAnswer.Text
            RefreshQueuePage()
        End If
    End Sub

    Private Sub CheckBoxAllCounterstats_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxAllCounterstats.CheckedChanged
        AllCounterStats = CheckBoxAllCounterstats.Enabled
        RefreshQueuePage()
    End Sub

    Private Sub LinkLabelClinthBlog_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabelClinthBlog.LinkClicked
        Dim sInfo As New ProcessStartInfo(e.Link.LinkData.ToString())
        Process.Start(sInfo)
    End Sub

    Private Sub LinkLabelEmailClint_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabelEmailClint.LinkClicked
        Dim sInfo As New ProcessStartInfo(e.Link.LinkData.ToString())
        Process.Start(sInfo)
    End Sub

    Private Sub LinkLabelAboutTheAuthorClintH_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabelAboutTheAuthorClintH.LinkClicked
        Dim sInfo As New ProcessStartInfo(e.Link.LinkData.ToString())
        Process.Start(sInfo)
    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk
        Dim oPALFunctions As New PALFunctions.PALFunctions
        Dim sPerfmonLogTemplateBody As String
        Const WINSEVEN = 1, WINSIX = 2, LOGMAN = 3

        Select Case SaveFileDialog1.FilterIndex
            Case WINSIX
                sPerfmonLogTemplateBody = oPALFunctions.ExportThresholdFileToPerfmonTemplate(ThresholdFilePath)
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, sPerfmonLogTemplateBody, False)
            Case WINSEVEN
                sPerfmonLogTemplateBody = oPALFunctions.ExportThresholdFileToDataCollectorTemplate(ThresholdFilePath)
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, sPerfmonLogTemplateBody, False)
            Case LOGMAN
                sPerfmonLogTemplateBody = oPALFunctions.ExportThresholdFileToLogmanCounterListFile(ThresholdFilePath)
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, sPerfmonLogTemplateBody, False, System.Text.Encoding.ASCII)
            Case Else
                sPerfmonLogTemplateBody = oPALFunctions.ExportThresholdFileToDataCollectorTemplate(ThresholdFilePath)
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, sPerfmonLogTemplateBody, False)
        End Select

        '// Special logic about SQL named instances
        If InStr(1, ThresholdFilePath, "SQL", CompareMethod.Text) > 0 Then
            MsgBox("The PAL tool is able to analyze Microsoft SQL Server named instance counters, but this Performance Monitor log template does not contain counters for Microsoft SQL Server named instances. When importing this template into Microsoft Performance Monitor, manually add Microsoft SQL Server named instance counters. This issue is due to the naming convention used by Microsoft SQL Server named instance performance counter paths.", MsgBoxStyle.Information, "Information About SQL Server Named Instances")
        End If
        '// End Special logic about SQL named instances
    End Sub

    Private Sub ExportToThresholdFileToPerfmonTemplate()
        If ThresholdFilePath = "" Then
            Exit Sub
        End If
        SaveFileDialog1.Filter = "Windows 2008/7 files (*.xml)|*.xml|Windows 2003/XP files (*.htm)|*.htm|Logman files (*.txt)|*.txt"
        SaveFileDialog1.ShowDialog()
    End Sub

    Private Sub ExportToWinSevenThresholdFileToPerfmonTemplate()
        Dim sPerfmonLogTemplateBody As String
        Dim oPALFunctions As New PALFunctions.PALFunctions
        If ThresholdFilePath = "" Then
            Exit Sub
        End If
        sPerfmonLogTemplateBody = oPALFunctions.ExportThresholdFileToPerfmonTemplate(ThresholdFilePath)
        SaveFileDialog1.Filter = "Windows 2008/7 files (*.xml)|*.xml|All Files (*.*)|*.*"
        If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, sPerfmonLogTemplateBody, False)
        End If
        '// Special logic about SQL named instances
        If InStr(1, ThresholdFilePath, "SQL", CompareMethod.Text) > 0 Then
            MsgBox("The PAL tool is able to analyze Microsoft SQL Server named instance counters, but this Performance Monitor log template does not contain counters for Microsoft SQL Server named instances. When importing this template into Microsoft Performance Monitor, manually add Microsoft SQL Server named instance counters. This issue is due to the naming convention used by Microsoft SQL Server named instance performance counter paths.", MsgBoxStyle.Information, "Information About SQL Server Named Instances")
        End If
        '// End Special logic about SQL named instances
    End Sub

    Private Sub ExportToWinSixThresholdFileToPerfmonTemplate()
        Dim sPerfmonLogTemplateBody As String
        Dim oPALFunctions As New PALFunctions.PALFunctions
        If ThresholdFilePath = "" Then
            Exit Sub
        End If
        sPerfmonLogTemplateBody = oPALFunctions.ExportThresholdFileToPerfmonTemplate(ThresholdFilePath)
        SaveFileDialog1.Filter = "Windows 2003/XP files (*.htm)|*.htm|All Files (*.*)|*.*"
        If SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, sPerfmonLogTemplateBody, False)
        End If
        '// Special logic about SQL named instances
        If InStr(1, ThresholdFilePath, "SQL", CompareMethod.Text) > 0 Then
            MsgBox("The PAL tool is able to analyze Microsoft SQL Server named instance counters, but this Performance Monitor log template does not contain counters for Microsoft SQL Server named instances. When importing this template into Microsoft Performance Monitor, manually add Microsoft SQL Server named instance counters. This issue is due to the naming convention used by Microsoft SQL Server named instance performance counter paths.", MsgBoxStyle.Information, "Information About SQL Server Named Instances")
        End If
        '// End Special logic about SQL named instances
    End Sub

    Private Sub LinkLabelSupport_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabelSupport.LinkClicked
        Dim sInfo As New ProcessStartInfo(e.Link.LinkData.ToString())
        Process.Start(sInfo)
    End Sub
End Class






